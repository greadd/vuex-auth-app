<template>
  <v-overlay>
    <v-progress-circular indeterminate size="80"></v-progress-circular>
  </v-overlay>
</template>
