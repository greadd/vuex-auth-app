<template>
  <v-app>
    <v-main class="blue lighten-3 ">
      <v-container fluid class="fill-height">
        <v-row align="center" justify="center">
          <router-view />
        </v-row>
      </v-container>
    </v-main>
  </v-app>
</template>
